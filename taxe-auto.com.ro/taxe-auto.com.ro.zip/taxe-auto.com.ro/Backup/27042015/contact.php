<?php

include 'config.php';


$to = $EMAIL_ADDRESS;
$subject = 'Mesaj din cadrul site-ului www.starc.ro';
$message = 'Numele: ' . $_POST['name'] . '      E-mail: ' . $_POST['sender'] . '      Telefon: ' . $_POST['phone'] . '      Mesajul: ' . $_POST['msg'];
$headers = 'From: ' . $_POST['sender'] . "\r\n" .
        'Reply-To: ' . $_POST['sender'] . "\r\n" .
        'X-Mailer: PHP/' . phpversion();

$result = mail($to, $subject, $message, $headers);

header('Location: http://www.taxe-auto.com.ro/contact.html');
exit();
?>
