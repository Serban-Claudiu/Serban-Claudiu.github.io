<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Cumpara online rovinieta si asigurarea RCA sau CASCO</title>
<link rel="SHORTCUT ICON" href="favicon.png">
<link href="taxeauto.css" type="text/css" rel="stylesheet">
<script language="javascript" type="text/JavaScript" src="funcs.js"></script>

<script type="text/javascript">
 var RecaptchaOptions = {
    theme : 'custom',
    custom_theme_widget: 'recaptcha_widget'
 };

 </script>

</head>

<body>

<div id="top_container">
	<div id="header">
		<div id="logo"></div>
		<div id="slogan">Cumpara online rovinieta si asigurarea RCA sau CASCO</div>
		<div class="clearboth"></div>
		<div id="menu">
			<ul>	
				<li class="menu_mar"></li>
				<li><a href="index.html" class="menu">Acasa</a></li>
				<li class="menu_sep"></li>
				<li><a href="rovinieta.html" class="menu">Rovinieta</a></li>
				<li class="menu_sep"></li>
				<li><a href="rca.html" class="menu">RCA</a></li>
				<li class="menu_sep"></li>
				<li><a href="casco.html" class="menu">CASCO</a></li>
				<li class="menu_sep"></li>
				<li><a href="asistenta_rutiera.html" class="menu">Asigurare de calatorie</a></li>
				<li class="menu_sep"></li>
				<li><a href="persoane_juridice.html" class="menu">Persoane Juridice</a></li>
				<li class="menu_sep"></li>
				<li><a href="contact.html" class="menu">Contact</a></li>
				<li class="menu_sep"></li>
			</ul>
		</div>
		<div id="submenu">
			<div id="url">www.taxe-auto.com.ro</div>
		</div>
	</div>



	<div id="middle_container">
		<div class="clearboth"></div>
		<div id="content" style="width:558px">
		  <div id="content_title">Contact</div>
			<div id="cont1">
				<div id="header1"></div>
		      <div class="text txt">
		        <form action="contact.html" method="post" name="mail" id="mail" onsubmit="return chkFormular()">
                  <table border="0" align="center" cellpadding="2" cellspacing="5">
                    <tbody><tr>
                      <td align="right" class="text"><strong>* Nume / Prenume:</strong></td>
                      <td><input name="name" value="" size="35" align="left"></td>
                    </tr>
                    <tr>
                      <td align="right" class="text"><strong>* Email:</strong></td>
                      <td><input name="email" value="" size="35" align="left"></td>
                    </tr>
                    <tr>
                      <td align="right" class="text"><strong>Telefon:</strong></td>
                      <td><input name="phone" value="" size="35" align="left"></td>
                    </tr>
                    <tr>
                      <td align="right" valign="top" class="text"><strong>* Mesaj:</strong></td>
                      <td><textarea name="comment" cols="45" rows="6"></textarea></td>
                    </tr>
                    <tr>
                      <td align="right" class="text"><b>Codul de verificare :</b></td>
                      <td><input name="check_ch" type="text" id="check_ch"></td>
                    </tr>
                    <tr>
                      <td></td>
                      <td></td>

                    </tr>
                    <tr>
                      <td></td>
                      <td>
						require_once('recaptchalib.php');
						$publickey = "6LdzmukSAAAAAHK__SUnf0_OYeYyfxejAwwxfb-P"; // you got this from the signup page
						echo recaptcha_get_html($publickey);
					  <input type="submit" name="Submit" value="Trimite" class="btn">
					  <div class="btn_sh"></div>					  </td>
                    </tr>
                    <tr>
                      <td height="40"></td>
                      <td class="text">Campurile cu * sunt obligatorii ! </td>
                    </tr>
                  </tbody></table>
	            </form>
		      </div>
			</div>
	  </div>


<div id="rightmenu" style="width:427px">
		<br />
	<div id="auto_logos"></div>
	<div style="text-align:center">
		<a href='http://bit.ly/ro_vinieta' target='_blank' rel='nofollow'><img src='http://bit.ly/ro_vinieta_img' alt='Rovinieta' title='Rovinieta' border='0' /></a>
		<br />
		<br />
		<a href='http://bit.ly/ro_rca1' target='_blank' rel='nofollow'><img src='http://bit.ly/ro_rca1_img' alt='RCA-Ieftin' title='RCA-Ieftin' border='0' /></a>
		<br />
		<br />
		<a href='http://bit.ly/ro_rca2' target='_blank' rel='nofollow'><img src='http://bit.ly/ro_rca2_img' alt='RCA-Ieftin' title='RCA-Ieftin' border='0' /></a>
		<br />
		<a href='http://bit.ly/ro_rca2' target='_blank' rel='nofollow'><img src='images/cere_oferta.png' alt='RCA-Ieftin' title='RCA-Ieftin' border='0' /></a>
		<br />
		<br />
		<a href='http://bit.ly/ro_casco' target='_blank' rel='nofollow'><img src='http://bit.ly/ro_casco_img' alt='RCA-Ieftin' title='RCA-Ieftin' border='0' /></a>
		<br />
		<a href='http://bit.ly/ro_casco' target='_blank' rel='nofollow'><img src='images/cere_oferta.png' alt='RCA-Ieftin' title='RCA-Ieftin' border='0' /></a>
		<br />
		<br />
		<br />
	</div>		 
	
		<br />
			</div>
		<br />
		</div>
	</div>
</div>


</body>

</html>