<?php

$EMAIL_ADDRESS = 'serban@bistriceanu.eu';

$message_contact_ok = 'Mesajul dumneavoastra a fost trimis. Va multumim!';
$message_contact_error = 'Ceva nu a mers cum trebuia. Incercati mai tarziu.';
?>
